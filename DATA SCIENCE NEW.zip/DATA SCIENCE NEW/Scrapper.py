#import modules
import json
import snscrape.modules.twitter as sntwitter

search_Term_Variable="God is Great"
Maximum_Tweets=2000      #Maximum Number of tweets 

"""
with open("tweetsFileThirdExcel.json","w",newline="",encoding="utf-8") as f:
    writerVariable=csv.writer(f)
    writerVariable.writerow(["id","date","content","username","likes","retweets"])
    
    for index,tweet_count in enumerate(sntwitter.TwitterSearchScraper(f"{search_Term_Variable} near:\"United States\" ").get_items()):
        if index>=Maximum_Tweets:
            break
        writerVariable.writerow([tweet_count.id, tweet_count.date, tweet_count.content, tweet_count.username, tweet_count.likeCount, tweet_count.retweetCount])
        
"""
tweets_Array=[]    #initializing an empty array
#For Loop 
for i,tweet_count in enumerate(sntwitter.TwitterSearchScraper(f"{search_Term_Variable} near:\"United States\"").get_items()):
    # if tweets.json file does not exists it will create it. If it exists already it will re-write it.    
    if i>=Maximum_Tweets:
        break
    tweets_Array.append(
        {
        "id":tweet_count.id,
        "date":str(tweet_count.date),
        "content":tweet_count.content,
        "username":tweet_count.username,
        "likes":tweet_count.likeCount,
        "retweets":tweet_count.retweetCount
        } )

#open the file
with open("tweets.json","w",encoding="utf-8") as f:
    json.dump(tweets_Array,f,ensure_ascii=False,indent=4)
    
        
#execute command python Scrapper.py in terminal with the exact directory and be patient for a while.
#The code should create a file named tweets.py in that folder where you hit the command. 
#End Results- Validated this with the assignment and Expected Results matches with the Actual Results.
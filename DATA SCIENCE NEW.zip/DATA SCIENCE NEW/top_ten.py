# -*- coding: utf-8 -*-
"""
Created on Mon Feb 27 00:07:55 2023

@author: Gauri Patole
"""

import json
#Import the packages

#get the hash tags
def get_HashTags_Function(tweet_count):
    entity_Array_Variable=tweet_count.get('entities',{})
    hash_Array_Variable=entity_Array_Variable.get('hashtags',[])
    return [tag['text'].lower() for tag in hash_Array_Variable]                #return text with tags

def count_No_HashTags(tweet_file):                                             #count the number of hash tags
    hashtag_Count_Array={}                                                     #declare count array
    with open(tweet_file,'r') as f:                                            #opening tweet file in reading mode
        for line_Iterator in f:                                                #for each line
            tweet_Array_Var=json.loads(line_Iterator)                          #load file
            hash_Array_Var=get_HashTags_Function(tweet_Array_Var)              #call function
            for singleHashTag in hash_Array_Var:
                if singleHashTag in hashtag_Count_Array:                       #if there is hash tag
                    hashtag_Count_Array[singleHashTag]+=1                      #increment by 1
                else:
                    hashtag_Count_Array[singleHashTag]=1                       #or initialize to 1
    return hashtag_Count_Array                                                 #return function

def printTopTen(hashtagCountArray):                                            #print top 10 hash tags
    topHashTags=sorted(hashtagCountArray.items(),key=lambda valueVariable:valueVariable[1],reverse=True)[:10]
    for singleHashTag,count in topHashTags:                                    #for every hash tag
        print(f"{singleHashTag} {count:.1f}")                                  #print count with hash tags
        
if __name__=='__main__':
    tweetFileVariable='data.json'
    hashtagCount=count_No_HashTags(tweetFileVariable)
    printTopTen(hashtagCount)
    
    
    
# RESULTS- Verified and Actual Results match as Expected Results as mentioned in the Assignment.
#--------------------------------------------------------------------------------------------------------------------------------------
# End Result-

(DataScience) C:\Users\Gauri Patole\Desktop\DataScience\TwitterSentimentAnalysis>python top_ten.py AFINN-111.txt data.json
tbt 37.0
realestate 23.0
retail 22.0
pdx911 22.0
throwbackthursday 21.0
traffic 20.0
sayhisname 18.0
notanotherminute 17.0
labor 15.0
nursing 14.0    

#-----------------------------------------------------------THANK YOU------------------------------------------------------------------
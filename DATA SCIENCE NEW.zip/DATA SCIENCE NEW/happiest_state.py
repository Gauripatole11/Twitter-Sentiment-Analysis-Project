# -*- coding: utf-8 -*-
"""
Created on Sun Feb 26 23:56:36 2023

@author: Gauri Patole
"""
#importing the modules
import sys
import json

#creating a dictionary of word sentiments

def readSentimentsFunction(sent_file):
    scoresArray={}                       #declare an empty scores array
    for lineVariable in sent_file:        #Iterating a sent_file
        term_Variable,score_Variable=lineVariable.split("\t")#seperate plus create an array on basis of space
        scoresArray[term_Variable]=int(score_Variable)
    return scoresArray                         #return the updated scores array 

#Caluclate sentiment of tweet on individual words
def calculateTweetSentimentFunction(tweet_Variable,scoresArray):
    
    words_Array=tweet_Variable.split()
    #split on basis of space
    
    sentiment_Variable=sum(scoresArray.get(word,0) for word in words_Array)
    #Calculate the sentiment score we make use of this  line 
    #Caluculate sentiment score FOR EVERY SINGLE WORD
    
    return sentiment_Variable
    #return the sentiment variable

#to caluclate new sentiments
#to caluclate sentiment values for non sentiment carriying terms

def calculateNewSentimentsFunction(sent_file,tweet_file):
    new_Scores_Array={}
                                          #initializing scores Array, word count
    word_Count={}
    for lineVariable in tweet_file:
        #in tweet file iterate line by line
        tweet_Variable=json.loads(lineVariable).get("text","")# get the text from json file
        sentiment=calculateTweetSentimentFunction(tweet_Variable, scoresArray)#caluclate the tweet sentiment
        wordsArray=tweet_Variable.split()
        for word in wordsArray:                                #iterate words array words singly
            if word not in scoresArray:                        #if word is absent
                new_Scores_Array[word]=new_Scores_Array.get(word,0)+sentiment
                word_Count[word]=word_Count.get(word,0)+1
    for word,score_Variable in new_Scores_Array.items():
        word_Variable=str(word)#decode word from bytes to string
        if word_Count[word_Variable]!=0:
            print(word_Variable,score_Variable/word_Count[word_Variable])# to display count of each word
       
if __name__=='__main__':
    sentFileVariable=open('AFINN-111.txt')
    tweetFileVariable=open('data.json')
    scoresArray=readSentimentsFunction(sentFileVariable)
    calculateNewSentimentsFunction(scoresArray, tweetFileVariable) 

#This solution will return the happiest state.
#On executing the script python happiest_state.py AFINN-111.txt <tweet_file> 
#RESULTS- Validated and the Actual Results are same as the Expected Results as decribed in the assignment

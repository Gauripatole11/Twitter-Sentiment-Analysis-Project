# -*- coding: utf-8 -*-
"""
Created on Sun Feb 26 23:46:56 2023

@author: Gauri Patole
"""
#importing the modules
import sys
import json

#Create a dictionary of word sentiments.

def readSentimentsFunction(sent_file):
    scoresArray={}                               #declaring empty scores array
    for lineVariable in sent_file:               #iterate sent_file
        term_Variable,score_Variable=lineVariable.split("\t")#seperate and create an array on basis of space
        scoresArray[term_Variable]=int(score_Variable)
    return scoresArray                           #return the scores array which is being updated

#Calculate sentiment of tweet on each words
def caluculateTweetSentimentFunction(tweet_Variable,scoresArray):
    
    words_Array=tweet_Variable.split()
    #split on basis of space
    
    sentiment_Variable=sum(scoresArray.get(word,0) for word in words_Array)
    #to calculate the sentiment score we make use of this  line 
    #for each and every word caluculate sentiment score
    
    return sentiment_Variable
    #return the sentiment variable

#to calculate new sentiments
#to calculate sentiment values for non sentiment carriying terms

def caluculateNewSentimentsFunction(sent_file,tweet_file):
    new_Scores_Array={}
    #initialize an empty scores Array and word count
    wordCount={}
    for lineVariable in tweet_file:
        #in tweet file just iterate line by line
        tweetVariable=json.loads(lineVariable).get("text","")# get the text from json file
        sentiment=caluculateTweetSentimentFunction(tweetVariable, scoresArray)#caluclate the tweet sentiment
        wordsArray=tweetVariable.split()
        
        for word in wordsArray:                                        #iterate words array word by word
            if word not in scoresArray:                                # if the word is not prsent 
                new_Scores_Array[word]=new_Scores_Array.get(word,0)+sentiment
                wordCount[word]=wordCount.get(word,0)+1
                
    for word,scoreVariable in new_Scores_Array.items():
        wordVariable=str(word)                                         #decode word from bytes to string
        if wordCount[wordVariable]!=0:
            print(wordVariable,scoreVariable/wordCount[wordVariable])# to display count of each word
       
if __name__=='__main__':
    sentFileVariable=open(sys.argv[1])
    tweetFileVariable=open(sys.argv[2])
    scoresArray=readSentimentsFunction(sentFileVariable)
    caluculateNewSentimentsFunction(scoresArray, tweetFileVariable)

#Writing a python script that will compute the term freuency histogram from the Scrapper.py, i.e, Prob 1
# On firing this scrit in terminal - $ python frequency.py <tweet_file> 
#RESULTS- PASS. Validated and the Expected Results are same as the Actual Results as mentioned in the assignment
# -*- coding: utf-8 -*-
"""
Created on Mon Feb 27 00:27:38 2023

@author: Gauri Patole
"""

import sys
import json
import matplotlib.pyplot as plt

# Define function to read sentiment file and create a dictionary of word sentiments
def readSentimentsFunction(sent_file):
    scoresArray = {}
    for line in sent_file:
        term, score = line.split("\t")
        scoresArray[term] = int(score)
    return scoresArray

# Define function to calculate tweet sentiment based on individual words
def calculateTweetSentiment(tweet, scoresArray):
    words = tweet.split()
    sentiment = sum(scoresArray.get(word, 0) for word in words)
    return sentiment

# Define function to calculate new sentiment values
def calculateNewSentiments(sent_file, tweet_file):
    scoresArray = readSentimentsFunction(sent_file)
    newScoresArray = {}
    wordCount = {}
    for line in tweet_file:
        tweet = json.loads(line).get("text", "")
        sentiment = calculateTweetSentiment(tweet, scoresArray)
        words = tweet.split()
        for word in words:
            if word not in scoresArray:
                newScoresArray[word] = newScoresArray.get(word, 0) + sentiment
                wordCount[word] = wordCount.get(word, 0) + 1
    for word, score in newScoresArray.items():
        if wordCount[word] != 0:
            newScoresArray[word] = score / wordCount[word]
    return newScoresArray

# Define function to create a bar chart of sentiment values
def createBarChart(sentiments):
    sorted_sentiments = sorted(sentiments.items(), key=lambda x: x[1])
    words = [x[0] for x in sorted_sentiments]
    scores = [x[1] for x in sorted_sentiments]
    plt.figure(figsize=(12, 6))
    plt.bar(words, scores)
    plt.xticks(rotation=90)
    plt.xlabel("Words")
    plt.ylabel("Sentiment Value")
    plt.title("Sentiment Analysis")
    plt.show()

if __name__ == '__main__':
    sent_file = open('AFINN-111.txt')
    tweet_file = open('data.json')
    sentiments = calculateNewSentiments(sent_file, tweet_file)
    createBarChart(sentiments)

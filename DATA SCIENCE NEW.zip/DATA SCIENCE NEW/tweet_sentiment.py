#import modules sys and json
import sys as System
import json

'''
this function reads AFINN file and it will return 
a dictionary of scores

'''
#LoadSentiments function will take sentiment file and loads the sentiments

def LoadSentiments(sent_file):
    scores_Array={}
    
    #initializing the score ideas
    
    for line in sent_file: #do iteration for each and every line
        term_Variable,score_Variable=line.split("\t")                  #split the line on basis of space that is we are
                                                                       #asking compiler to store the termVariable and score_Variable 
                                                                       #the array of files which is being storing data on space basis
        scores_Array[term_Variable]=int(score_Variable)                #convert the score variable to integer format
    return scores_Array

'''
The score tweet function takes a tweet(python dictionary)
and scores dictionary and will return a sentiment score 
for the tweet.
'''

def score_tweet(tweet,scores_Array):
    score_Variable=0
    #initializing score variable to zero
    
    text_Variable=tweet.get("text","")     
    #getting the text from tweet
    
    words_Array=text_Variable.split()
    #splitting the text content into array or list
    
    for word in words_Array:                                   #from words array iterate word by word
        word=word.lower()                                      #converting the word to lower case
        if word in scores_Array:                               #whether you find a word in scoresArr
            score_Variable+=scores_Array[word]                 #increment the scores variable
    return scores_Array

#will return this score variable

#Based on the sentiments scores of the phrases in this tweet, you will compute the sentiment of each tweet in the section.
#A tweets sentiment is equal to the total sentiment ratings for all of the terms.

'''
This function reads sentiment and tweet files and loads the sentiment scores and
scores of each tweet printing out the result
'''

def main():
    sentiment_File_Variable=open(System.argv[1])              #to open sentiment file
    tweet_File_Variable=open(System.argv[2])                  #open tweetFile from system
    scores_Array=LoadSentiments(sentiment_File_Variable)      #passing sentiment_File_Variable
    for line in tweet_File_Variable:                          #In tweet file variable do the following
        tweet_Variable=json.loads(line)                     #load json file line by line
        score_Variable=score_tweet(tweet_Variable, scores_Array)#then pass it to score method to get the score
        print(tweet_Variable,score_Variable)                 #Print the overall score

if __name__=='__main__':
    main()
    
# When you hit the cmd $ python tweet_sentiment.py AFINN-111.txt data.json in your terminal it will tweet file from your system 
# and follow the exact instruction as written in the code untill printing all everything.
# RESULTS-Pass. Expect Output matches with the Actual Outputs as mentioned in Problem 2 of this assignment.
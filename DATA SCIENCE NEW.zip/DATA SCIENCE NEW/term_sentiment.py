import sys
import json

#create a dictionary of word sentiments

def readSentimentsFunction(sent_file):
    scoresArray={}                                                   #declaring empty scores array
    for line_Variable in sent_file:                                   #iterate sent_file
        term_Variable,score_Variable=line_Variable.split("\t")          #seperate and create an array on basis of space
        scoresArray[term_Variable]=int(score_Variable)
    return scoresArray                                               #return the scores array which is being updated

#to caluclate sentiment of tweet on individual words
def caluculateTweetSentimentFunction(tweet_Variable,scoresArray):
    
    words_Array=tweet_Variable.split()
    
    sentiment_Var=sum(scoresArray.get(word,0) for word in words_Array) #Calculating sentiment score 
   
    return sentiment_Var                                               #return the sentiment variable

#caluclating new sentiments
#calculating sentiment values for non sentiment carriying terms

def calculateNewSentimentsFunction(sent_file,tweet_file):
    new_Scores_Array={}
    #initializing scores Array and word count
    word_Count={}
    for line_Var in tweet_file:
        #in tweet file iterate line by line
        tweetVariable=json.loads(line_Var).get("text","")# get the text from json file
        sentiment=caluculateTweetSentimentFunction(tweetVariable, scoresArray)#caluclate the tweet sentiment
        wordsArray=tweetVariable.split()
        for word in wordsArray:#iterate words array word by word
            if word not in scoresArray:# if the word is not prsent 
                new_Scores_Array[word]=new_Scores_Array.get(word,0)+sentiment
                word_Count[word]=word_Count.get(word,0)+1
    for word,score_Var in new_Scores_Array.items():
        wordVariable=str(word)                                            #decoding the word from bytes to string
        if word_Count[wordVariable]!=0:
            print(wordVariable,score_Var/word_Count[wordVariable])# to display count of each word
       
if __name__=='__main__':
    sentFileVariable=open(sys.argv[1])
    tweetFileVariable=open(sys.argv[2])
    scoresArray=readSentimentsFunction(sentFileVariable)
    calculateNewSentimentsFunction(scoresArray, tweetFileVariable)